import subprocess
from os import remove, urandom
from os.path import join
from flask import Flask, render_template, request, flash, redirect


UPLOAD_FOLDER = '/home/user/app/vm'


app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 1 * 1000 * 1000
app.config['SECRET_KEY'] = urandom(12).hex()


@app.route('/', methods = ['GET', 'POST'])
def upload_file():
    
    
    if request.method == 'GET':
        return render_template('index.html', message='')

    if request.method == 'POST':
        if 'file' not in request.files:
            return render_template('index.html', message='no file :\'(')

        file = request.files.get('file')
        
        if file:
            file.save(join(app.config['UPLOAD_FOLDER'], "vm_data.bin"))

            message = ''

            try:
                message = subprocess.run(f"{UPLOAD_FOLDER}/vm", cwd=UPLOAD_FOLDER, timeout=2, shell=False,
                                         check=False, stdout=subprocess.PIPE).stdout.decode()
            except:
                message = "Too long"

            remove(join(app.config['UPLOAD_FOLDER'], "vm_data.bin"))
            
            return render_template('index.html', message=message)


    return render_template('index.html', message='')
	


if __name__ == '__main__':
   app.run(host="0.0.0.0")

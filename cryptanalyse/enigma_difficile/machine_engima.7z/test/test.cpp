#include "../cpp/enigma.h"
#include "../cpp/plugboard.h"
#include "../cpp/reflector.h"
#include "../cpp/rotor.h"
#include <gtest/gtest.h>
#include <ostream>
#include <string>

TEST(encrypt_text, simple) {
	Rotor right_rotor = Rotor::create("III", 'A', 'A');
	Rotor middle_rotor = Rotor::create("II", 'A', 'A');
	Rotor left_rotor = Rotor::create("I", 'A', 'A');

	Reflector reflector = Reflector::create("B");

	Plugboard plugboard{{}};

	Enigma enigma{left_rotor, middle_rotor, right_rotor, reflector, plugboard};

	std::string plain = "ABCDEF";

	std::string cipher = enigma.encrypt(plain);

	ASSERT_EQ(cipher, "BJELRQ");
}

TEST(encrypt_text, complex) {
	Rotor left_rotor = Rotor::create("IV", 'C', 'L');
	Rotor middle_rotor = Rotor::create("II", 'K', 'S');
	Rotor right_rotor = Rotor::create("III", 'K', 'Z');

	Reflector reflector = Reflector::create("C");
	Plugboard plugboard = Plugboard({"DF", "PG", "MB", "AZ", "HO", "WX"});

	Enigma e =
	    Enigma(left_rotor, middle_rotor, right_rotor, reflector, plugboard);

	std::string plain =
	    "ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEF"
	    "GHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKL"
	    "MNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ";

	std::string cipher = e.encrypt(plain);

	assert(cipher == "BZZZFQTOZZEAQISMXNLVTMLKWTTDRVWPFXERJHJZTJIKOMHTLLBBTUO"
	                 "UJVJKHNEZRVMDWFQWNHCHUENNQGGJODCXAXJUGUPSOEPDYIAWWZUMTE"
	                 "SOXWXYCAXRDAACJAPGLPTXNYBXCCVYHGFEHQUBZUQKESVF");
}

TEST(rotor, permute) {
	Rotor rotor = Rotor::create("I", 'A', 'A');

	for (char letter : alphabet) {
		std::cout << "letter:" << letter << " " << rotor.permute(letter)
		          << std::endl;
	}

	ASSERT_EQ(rotor.permute('A'), 'E');
	const std::string r1_str = "EKMFLGDQVZNTOWYHXUSPAIBRCJ";
	for (int i = 0; i < alphabet.size(); i++) {
		ASSERT_EQ(rotor.permute(alphabet.at(i)), r1_str.at(i));
	}

	rotor.rotate();

	ASSERT_EQ(rotor.permute('A'), 'J');
}

TEST(rotor, inv_permute) {
	Rotor rotor = Rotor::create("I", 'A', 'A');

	ASSERT_EQ(rotor.inv_permute(rotor.permute('A')), 'A');

	for (char letter : alphabet) {
		std::cout << "letter:" << letter << " " << rotor.inv_permute(letter)
		          << std::endl;
		ASSERT_EQ(rotor.inv_permute(rotor.permute(letter)), letter);
	}

	rotor.rotate();

	for (char letter : alphabet) {
		ASSERT_EQ(rotor.inv_permute(rotor.permute(letter)), letter);
	}
}

int main(int argc, char **argv) {
	::testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}

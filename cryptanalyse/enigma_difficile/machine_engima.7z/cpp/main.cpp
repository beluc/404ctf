#include "enigma.h"
#include "plugboard.h"
#include "reflector.h"
#include "rotor.h"
#include <iostream>

int main(int argc, char *argv[]) {

	std::string text = "BONJOUR CECI EST UN TEXTE";

	Rotor left_rotor = Rotor::create("I", 'H', 'M'),
	      middle_rotor = Rotor::create("II", 'E', 'C'),
	      right_rotor = Rotor::create("III", 'T', 'U');

	Reflector reflector = Reflector::create("B");

	Plugboard plugboard{{"AB", "CD", "EF"}};

	Enigma enigma =
	    Enigma(left_rotor, middle_rotor, right_rotor, reflector,
	    plugboard);

	std::string res = enigma.encrypt(text);

	std::cout << res << std::endl;

	return 0;
}

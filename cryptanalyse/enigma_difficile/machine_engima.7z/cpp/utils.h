#ifndef UTILS_H_
#define UTILS_H_

#include <string>
#include <string_view>
#include <tuple>
#include <vector>

constexpr std::string_view alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

constexpr ssize_t modulus(ssize_t a, ssize_t b) {
    return ((a % b) + b) % b;
}


std::tuple<std::string_view, std::string_view, std::vector<char>> R1("I", "EKMFLGDQVZNTOWYHXUSPAIBRCJ", {'Q'});
std::tuple<std::string_view, std::string_view, std::vector<char>> R2("II", "AJDKSIRUXBLHWTMCQGZNPYFVOE", {'E'});
std::tuple<std::string_view, std::string_view, std::vector<char>> R3("III", "BDFHJLCPRTXVZNYEIWGAKMUSQO", {'V'});
std::tuple<std::string_view, std::string_view, std::vector<char>> R4("IV", "ESOVPZJAYQUIRHXLNFTGKDCMWB", {'J'});
std::tuple<std::string_view, std::string_view, std::vector<char>> R5("V", "VZBRGITYUPSDNHLXAWMJQOFECK", {'Z'});



#endif // UTILS_H_

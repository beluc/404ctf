#ifndef ENIGMA_H_
#define ENIGMA_H_

#include "plugboard.h"
#include "reflector.h"
#include "rotor.h"
#include <algorithm>
#include <string>

class Enigma {

  public:
	Rotor left_rotor;
	Rotor middle_rotor;
	Rotor right_rotor;
	Reflector reflector;
	Plugboard plugboard;

	Enigma(Rotor left_rotor, Rotor middle_rotor, Rotor right_rotor,
	       Reflector reflector, Plugboard plugboard)
	    : left_rotor{left_rotor}, middle_rotor{middle_rotor},
	      right_rotor{right_rotor}, reflector{reflector}, plugboard{plugboard} {
	}

	char encrypt_letter(char letter, bool step = true) {
		if (step) {
			this->right_rotor.rotate();

			if (std::find(middle_rotor.notches.begin(),
			              middle_rotor.notches.end(),
			              alphabet.at(middle_rotor.position)) !=
			    middle_rotor.notches.end()) {
				middle_rotor.rotate();
			}

			if (right_rotor.complete_rotation) {
				middle_rotor.rotate();
				right_rotor.complete_rotation = false;
			}
			if (middle_rotor.complete_rotation) {
				left_rotor.rotate();
				middle_rotor.complete_rotation = false;
			}
		}

		char new_letter;
		new_letter = plugboard.permute(letter);

		new_letter = right_rotor.permute(new_letter);
		new_letter = middle_rotor.permute(new_letter);
		new_letter = left_rotor.permute(new_letter);

		new_letter = reflector.permute(new_letter);

		new_letter = left_rotor.inv_permute(new_letter);
		new_letter = middle_rotor.inv_permute(new_letter);
		new_letter = right_rotor.inv_permute(new_letter);

		new_letter = plugboard.permute(new_letter);

		return new_letter;
	}

	std::string encrypt(std::string &plain) {
		std::string cipher = "";
		cipher.reserve(plain.size());

		std::transform(plain.begin(), plain.end(), plain.begin(), ::toupper);

		for (int i = 0; i < plain.size(); i++) {
			if (alphabet.find(plain.at(i)) != std::string::npos) {
				cipher.push_back(encrypt_letter(plain.at(i)));
			} else {
				cipher.push_back(plain.at(i));
			}
		}
		return cipher;
	}
};

#endif // ENIGMA_H_

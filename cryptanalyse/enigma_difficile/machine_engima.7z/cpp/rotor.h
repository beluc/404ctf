#ifndef ROTOR_H_
#define ROTOR_H_

#include "utils.h"
#include <algorithm>
#include <iterator>
#include <stdexcept>
#include <string>
#include <vector>

class Rotor {
  public:
	std::string name;
	std::string rotor;
	std::vector<char> notches;
	std::string start;

	int ring_setting;
	int position;

	bool complete_rotation = false;

	Rotor(std::string name, std::string rotor, std::vector<char> notches,
	      char start, char ring_setting)
	    : name{name}, rotor{rotor}, notches{notches} {
		this->position = alphabet.find(start);
		if (this->position == alphabet.npos) {
			throw std::invalid_argument(rotor + " is not in alphabet.");
		}
		this->ring_setting = alphabet.find(ring_setting);
		if (this->ring_setting == alphabet.npos) {
			throw std::invalid_argument(rotor + " is not in alphabet.");
		}
	}

	static Rotor create(const std::string &rotor, char start,
	                    char ring_setting) {
		if (rotor == "I") {
			return Rotor("I", "EKMFLGDQVZNTOWYHXUSPAIBRCJ", {'Q'}, start,
			             ring_setting);
		} else if (rotor == "II") {
			return Rotor("II", "AJDKSIRUXBLHWTMCQGZNPYFVOE", {'E'}, start,
			             ring_setting);
		} else if (rotor == "III") {
			return Rotor("III", "BDFHJLCPRTXVZNYEIWGAKMUSQO", {'V'}, start,
			             ring_setting);
		} else if (rotor == "IV") {
			return Rotor("IV", "ESOVPZJAYQUIRHXLNFTGKDCMWB", {'J'}, start,
			             ring_setting);
		} else if (rotor == "V") {
			return Rotor("V", "VZBRGITYUPSDNHLXAWMJQOFECK", {'Z'}, start,
			             ring_setting);
		} else {
			throw std::invalid_argument(rotor + " is not a rotor.");
		}
	}

	void set_rotor(const std::tuple<std::string_view, std::string_view,
	                                std::vector<char>> &rotor) {
		this->name = std::get<0>(rotor);
		this->rotor = std::get<1>(rotor);
		this->notches = std::get<2>(rotor);
	}

	char permute(char letter) {

		int pos = modulus(letter - 65 + position - ring_setting,
		                  std::size(alphabet));

		char new_letter = rotor.at(pos);

		pos = modulus(static_cast<ssize_t>(new_letter - 65) - this->position +
		                  this->ring_setting,
		              alphabet.size());
		new_letter = alphabet.at(pos);

		return new_letter;
	}

	char inv_permute(char letter) {
		int pos = modulus(letter - 65 + this->position - this->ring_setting,
		                  std::size(alphabet));

		char new_letter = alphabet.at(pos);

		pos = modulus(static_cast<ssize_t>(
		                  std::find(rotor.begin(), rotor.end(), new_letter) -
		                  rotor.begin()) -
		                  position + ring_setting,
		              std::size(alphabet));
		new_letter = alphabet.at(pos);

		return new_letter;
	}

	void rotate() {
		position += 1;
		position %= rotor.size();

		if (std::find(
		        notches.begin(), notches.end(),
		        alphabet.at(modulus(position - 1, std::size(alphabet)))) !=
		    notches.end()) {
			complete_rotation = true;
		}
	}

	void reset_position() {
		position = 0;
		complete_rotation = false;
	}
};

#endif // ROTOR_H_

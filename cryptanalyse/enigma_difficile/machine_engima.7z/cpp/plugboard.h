#ifndef PLUGBOARD_H_
#define PLUGBOARD_H_

#include "utils.h"
#include <algorithm>
#include <ostream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

class Plugboard {
  public:
	std::unordered_map<char, char> permutations;

	Plugboard(std::vector<std::string> permutations_list) {
		for (std::string permutation : permutations_list) {
			if (permutations.count(permutation.at(0)) ||
			    permutations.count(permutation.at(1))) {
				throw std::invalid_argument(
				    "Letters can't be in two permutations.");
			}
			permutations[permutation.at(0)] = permutation.at(1);
			permutations[permutation.at(1)] = permutation.at(0);
		}
	}

	char permute(char letter) {
		char new_letter = letter;
		if (permutations.find(new_letter) != permutations.end()) {
			new_letter = permutations[new_letter];
		}
		return new_letter;
	}

	friend std::ostream &operator<<(std::ostream &os, const Plugboard &plug);
};

std::ostream &operator<<(std::ostream &os, const Plugboard &plug) {
	std::vector<char> printed_letters;
	bool first_letter = true;
	for (char letter : alphabet) {
		decltype(plug.permutations)::const_iterator permutation;
		if ((permutation = plug.permutations.find(letter)) !=
		    plug.permutations.end()) {
			if (std::find(printed_letters.begin(), printed_letters.end(),
			              permutation->first) == printed_letters.end()) {
				if (not first_letter) {
					os << " ";
				}
				first_letter = false;
				os << permutation->first << permutation->second;
				printed_letters.push_back(permutation->first);
				printed_letters.push_back(permutation->second);
			}
		}
	}
	return os;
}

#endif // PLUGBOARD_H_

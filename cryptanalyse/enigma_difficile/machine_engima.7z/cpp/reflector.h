#ifndef REFLECTOR_H_
#define REFLECTOR_H_

#include "rotor.h"
#include <stdexcept>
#include <string>

class Reflector {
  public:
	std::string reflector;

	Reflector(std::string reflector) : reflector{reflector} {}

	static Reflector create(std::string chosen_reflector) {
		if (chosen_reflector == "B") {
			return Reflector("YRUHQSLDPXNGOKMIEBFZCWVJAT");
		} else if (chosen_reflector == "C") {
			return Reflector("FVPJIAOYEDRZXWGCTKUQSBNMHL");
		} else {
			throw std::invalid_argument(chosen_reflector +
			                            " is not in list of reflectors.");
		}
	}

	char permute(char letter) {
		char new_letter = reflector.at(alphabet.find(letter));
		return new_letter;
	}
};

#endif // REFLECTOR_H_

# fmt: off
alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

R1: tuple[str, str, list[str]] = \
    ("I",
     'EKMFLGDQVZNTOWYHXUSPAIBRCJ',
     ['Q'])
R2: tuple[str, str, list[str]] = \
    ("II",
     'AJDKSIRUXBLHWTMCQGZNPYFVOE',
     ['E'])
R3: tuple[str, str, list[str]] = \
    ("III",
     'BDFHJLCPRTXVZNYEIWGAKMUSQO',
     ['V'])
R4: tuple[str, str, list[str]] = \
    ("IV",
     'ESOVPZJAYQUIRHXLNFTGKDCMWB',
     ['J'])
R5: tuple[str, str, list[str]] = \
    ("V",
     'VZBRGITYUPSDNHLXAWMJQOFECK',
     ['Z'])

B: str = 'YRUHQSLDPXNGOKMIEBFZCWVJAT'
C: str = 'FVPJIAOYEDRZXWGCTKUQSBNMHL'
# fmt: on


class Rotor:
    def __init__(
        self,
        rotor: tuple[str, str, list[str]],
        position_str: str,
        ring_setting_str: str,
    ):
        self.rotor: tuple[str, str, list[str]] = rotor[1]
        self.notch: list[str] = rotor[2]
        self.position: int = alphabet.index(position_str)
        self.alphabet: str = alphabet[:]
        self.complete_rotation: bool = False
        self.ring_setting: int = alphabet.index(ring_setting_str)

    def permute(self, letter: str) -> str:
        pos = (alphabet.index(letter) + self.position - self.ring_setting) % len(
            alphabet
        )
        new_letter = self.rotor[pos]
        pos = (alphabet.index(new_letter) - self.position + self.ring_setting) % len(
            alphabet
        )
        new_letter = self.alphabet[pos % len(self.alphabet)]
        return new_letter

    def inv_permute(self, letter: str) -> str:
        pos = (alphabet.index(letter) + self.position - self.ring_setting) % len(
            alphabet
        )
        new_letter = alphabet[pos]
        pos = (self.rotor.index(new_letter) - self.position + self.ring_setting) % len(
            alphabet
        )
        new_letter = alphabet[pos]

        return new_letter

    def rotate(self):
        """
        Rotate the rotor.
        If the rotor made a full rotation, set self.complete_rotation to true.
        """
        self.position += 1
        self.position %= len(self.rotor)

        if alphabet[(self.position - 1) % len(alphabet)] in self.notch:
            self.complete_rotation = True

    def reset_position(self):
        self.position = 0


class Reflector:
    def __init__(self, reflector: str):
        self.reflector = reflector

    def permute(self, letter: str):
        new_letter = self.reflector[alphabet.index(letter)]
        return new_letter


class Plugboard:
    def __init__(self, permutations_list: str):
        """permutation_list is a string of the form "AB CD EF" containing the permutations to do."""
        self.permutations: dict = dict()

        for permutation in permutations_list.split():
            if (
                permutation[0] in self.permutations
                or permutation[1] in self.permutations
            ):
                raise ValueError("A letter can't be in two permutations")
            self.permutations[permutation[0]] = permutation[1]
            self.permutations[permutation[1]] = permutation[0]

    def permute(self, letter: str):
        new_letter = letter
        if letter in self.permutations:
            new_letter = self.permutations[new_letter]
        return new_letter


class Enigma:
    def __init__(
        self,
        left_rotor: Rotor,
        middle_rotor: Rotor,
        right_rotor: Rotor,
        reflector,
        plugboard: Plugboard,
    ):
        self.left_rotor = left_rotor
        self.middle_rotor = middle_rotor
        self.right_rotor = right_rotor
        self.reflector = reflector
        self.plugboard = plugboard

    def encrypt_letter(self, letter: str, step: bool = True) -> str:

        if step:
            self.right_rotor.rotate()

            # There is an unintentional mechanism that causes the middle rotor to "double step" under certain conditions
            if alphabet[self.middle_rotor.position] in self.middle_rotor.notch:
                self.middle_rotor.rotate()

            if self.right_rotor.complete_rotation:
                self.middle_rotor.rotate()
            if self.middle_rotor.complete_rotation:
                self.left_rotor.rotate()

            self.right_rotor.complete_rotation = False
            self.middle_rotor.complete_rotation = False
            self.left_rotor.complete_rotation = False

        new_letter = self.plugboard.permute(letter)
        new_letter = self.right_rotor.permute(new_letter)
        new_letter = self.middle_rotor.permute(new_letter)
        new_letter = self.left_rotor.permute(new_letter)

        new_letter = self.reflector.permute(new_letter)

        new_letter = self.left_rotor.inv_permute(new_letter)
        new_letter = self.middle_rotor.inv_permute(new_letter)
        new_letter = self.right_rotor.inv_permute(new_letter)

        new_letter = self.plugboard.permute(new_letter)

        return new_letter

    def encrypt(self, plain: str):
        cipher = ""
        text = plain.upper()
        for letter in text:
            if letter in alphabet:
                cipher += self.encrypt_letter(letter)
            else:
                cipher += letter

        return cipher

    def reset_positions(self):
        self.left_rotor.reset_position()
        self.middle_rotor.reset_position()
        self.right_rotor.reset_position()


if __name__ == "__main__":
    l_rotor = Rotor(R1, "A", "D")
    m_rotor = Rotor(R2, "B", "E")
    r_rotor = Rotor(R3, "C", "F")

    ref = Reflector(B)

    plug = Plugboard("AB CD EF")

    e = Enigma(l_rotor, m_rotor, r_rotor, ref, plug)

import pytest
import enigma


def test_encrypt_text():
    right_rotor = enigma.Rotor(enigma.R3, "A", "A")
    middle_rotor = enigma.Rotor(enigma.R2, "A", "A")
    left_rotor = enigma.Rotor(enigma.R1, "A", "A")

    reflector = enigma.Reflector(enigma.B)
    plugboard = enigma.Plugboard("")

    e = enigma.Enigma(left_rotor, middle_rotor, right_rotor, reflector, plugboard)

    plain = "ABCDEF"

    cipher = e.encrypt(plain)

    assert cipher == "BJELRQ"


def test_encrypt_text2():
    right_rotor = enigma.Rotor(enigma.R3, "A", "A")
    middle_rotor = enigma.Rotor(enigma.R2, "A", "A")
    left_rotor = enigma.Rotor(enigma.R1, "A", "A")

    reflector = enigma.Reflector(enigma.B)
    plugboard = enigma.Plugboard("")

    e = enigma.Enigma(left_rotor, middle_rotor, right_rotor, reflector, plugboard)

    plain = "ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ"

    cipher = e.encrypt(plain)

    assert (
        cipher
        == "BJELRQZVJWARXSNBXORSTNCFMEYYAQUSQSWSQYPAJCKCZEJUDSIUPPTCCBZUHRQRPWJBPCAAZPJZZWDAZIHVYGPITMSRZKGGHLSRBLHLFKELOAYCSWCMUGNZCEDQOMKPEH"
    )


def test_encrypt_test3():
    right_rotor = enigma.Rotor(enigma.R3, "A", "A")
    middle_rotor = enigma.Rotor(enigma.R2, "A", "A")
    left_rotor = enigma.Rotor(enigma.R1, "A", "A")

    reflector = enigma.Reflector(enigma.B)
    plugboard = enigma.Plugboard("")

    e = enigma.Enigma(left_rotor, middle_rotor, right_rotor, reflector, plugboard)

    plain = (
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    )

    cipher = e.encrypt(plain)

    assert (
        cipher
        == "BDZGOWCXLTKSBTMCDLPBMUQOFXYHCXTGYJFLINHNXSHIUNTHEORXPQPKOVHCBUBTZSZSOOSTGOTFSODBBZZLXLCYZXIFGWFDZEEQIBMGFJBWZFCKPFMGBXQCIVIBBRNCOCJUVYDKMVJPFMDRMTGLWFOZLXGJEYYQPVPBWNCKVKLZT"
    )


def test_enigma_tes5():
    left_rotor = enigma.Rotor(enigma.R4, "A", "A")
    middle_rotor = enigma.Rotor(enigma.R2, "A", "A")
    right_rotor = enigma.Rotor(enigma.R3, "A", "A")

    reflector = enigma.Reflector(enigma.C)
    plugboard = enigma.Plugboard("DF PG MB AZ HO WX")

    e = enigma.Enigma(left_rotor, middle_rotor, right_rotor, reflector, plugboard)

    plain = "ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ"

    cipher = e.encrypt(plain)

    assert (
        cipher
        == "EGWEQDKVDSXYXBMSVABSTNDVKSNUVSUTZBACWMWMFTOXJDJUCQZWBTNPPEOIKEQVIGVXSCGKRWSWRPMVURFOSJGICDQFFINEFOEEIBVTDPTGSQEVMDUWDPUVNDNIGYCMZDPZSPWEOPKOPBBGCMEJEKPZGLDF"
    )


def test_enigma_test6():
    left_rotor = enigma.Rotor(enigma.R4, "C", "A")
    middle_rotor = enigma.Rotor(enigma.R2, "K", "A")
    right_rotor = enigma.Rotor(enigma.R3, "K", "A")

    reflector = enigma.Reflector(enigma.C)
    plugboard = enigma.Plugboard("DF PG MB AZ HO WX")

    e = enigma.Enigma(left_rotor, middle_rotor, right_rotor, reflector, plugboard)

    plain = "ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ"

    cipher = e.encrypt(plain)

    assert (
        cipher
        == "GLZMJAPZKKIMBWJTFHNXGQXMUUGGVMJBPLWGIBZRGQVCKDCGZMJJQPZEJXPINZVRCLFNNSEVFUGMBLLXDXJAPZKWNSGXEJPPOIORBOQMDGVRRZYCBIMBZRCRVUBMNGUZJUPVYYLIKDQGBIWQRWWMGGLBDYCR"
    )


def test_enigma_test7():
    left_rotor = enigma.Rotor(enigma.R4, "C", "A")
    middle_rotor = enigma.Rotor(enigma.R2, "K", "A")
    right_rotor = enigma.Rotor(enigma.R3, "K", "B")

    reflector = enigma.Reflector(enigma.C)
    plugboard = enigma.Plugboard("DF PG MB AZ HO WX")

    e = enigma.Enigma(left_rotor, middle_rotor, right_rotor, reflector, plugboard)

    plain = "AAA"

    cipher = e.encrypt(plain)

    assert cipher == "RGQ"


def test_enigma_test8():
    left_rotor = enigma.Rotor(enigma.R4, "C", "L")
    middle_rotor = enigma.Rotor(enigma.R2, "K", "S")
    right_rotor = enigma.Rotor(enigma.R3, "K", "Z")

    reflector = enigma.Reflector(enigma.C)
    plugboard = enigma.Plugboard("DF PG MB AZ HO WX")

    e = enigma.Enigma(left_rotor, middle_rotor, right_rotor, reflector, plugboard)

    plain = "ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ"

    cipher = e.encrypt(plain)

    assert (
        cipher
        == "BZZZFQTOZZEAQISMXNLVTMLKWTTDRVWPFXERJHJZTJIKOMHTLLBBTUOUJVJKHNEZRVMDWFQWNHCHUENNQGGJODCXAXJUGUPSOEPDYIAWWZUMTESOXWXYCAXRDAACJAPGLPTXNYBXCCVYHGFEHQUBZUQKESVF"
    )


def test_rotor_inv_permute():
    rotor = enigma.Rotor(enigma.R1, "A", "A")

    for letter in enigma.alphabet:
        assert rotor.inv_permute(rotor.permute(letter)) == letter

    rotor.rotate()
    for letter in enigma.alphabet:
        assert rotor.inv_permute(rotor.permute(letter)) == letter

    rotor = enigma.Rotor(enigma.R4, "R", "N")

    for letter in enigma.alphabet:
        assert rotor.inv_permute(rotor.permute(letter)) == letter

    rotor.rotate()
    for letter in enigma.alphabet:
        assert rotor.inv_permute(rotor.permute(letter)) == letter
